package com.funkmobile.daw

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF08090B)
private val Panel = Color(0xFF111318)
private val Grid = Color(0xFF242831)
private val Lime = Color(0xFFB7FF3C)
private val Text = Color(0xFFE8EAF0)
private val Muted = Color(0xFF858B98)

data class Track(val name: String, val type: String)

data class ClipData(val title: String, val start: Int, val length: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FunkMobile() }
    }
}

@Composable
fun FunkMobile() {
    var bpm by remember { mutableIntStateOf(130) }
    var playing by remember { mutableStateOf(false) }
    var selected by remember { mutableIntStateOf(0) }
    var tracks by remember { mutableStateOf(listOf(Track("Beat", "Drums"), Track("Bass", "Instrument"), Track("Melody", "Instrument"), Track("Vocal", "Audio"))) }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Lime)) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Header(bpm, { bpm = (bpm - 1).coerceAtLeast(40) }, { bpm = (bpm + 1).coerceAtMost(240) })
            Transport(playing, { playing = !playing }, { playing = false })
            TimelineNumbers()
            Row(Modifier.weight(1f)) {
                TrackList(tracks, selected, { selected = it }) { tracks = tracks + Track("Track ${tracks.size + 1}", "Audio") }
                Timeline(tracks.size, selected)
            }
        }
    }
}

@Composable
fun Header(bpm: Int, down: () -> Unit, up: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(58.dp).background(Panel).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("FUNK MOBILE", color = Text, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Text("BPM", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.width(8.dp))
        Row(Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF1A1D23)), verticalAlignment = Alignment.CenterVertically) {
            Text("−", color = Text, fontSize = 20.sp, modifier = Modifier.clickable { down() }.padding(horizontal = 9.dp, vertical = 4.dp))
            Text("$bpm", color = Lime, fontWeight = FontWeight.Bold, modifier = Modifier.width(40.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Text("+", color = Text, fontSize = 20.sp, modifier = Modifier.clickable { up() }.padding(horizontal = 9.dp, vertical = 4.dp))
        }
    }
}

@Composable
fun Transport(playing: Boolean, toggle: () -> Unit, stop: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(64.dp).background(Color(0xFF0D0F12)).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Button("■", stop, false); Spacer(Modifier.width(8.dp)); Button(if (playing) "Ⅱ" else "▶", toggle, true)
        Spacer(Modifier.width(18.dp)); Text(if (playing) "PLAYING" else "STOPPED", color = if (playing) Lime else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f)); Text("00:00:00", color = Text, fontSize = 15.sp)
    }
}

@Composable
fun Button(label: String, action: () -> Unit, primary: Boolean) {
    Box(Modifier.size(if (primary) 46.dp else 38.dp).clip(RoundedCornerShape(10.dp)).background(if (primary) Lime else Color(0xFF1A1D23)).clickable { action() }, contentAlignment = Alignment.Center) {
        Text(label, color = if (primary) Color.Black else Text, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun TimelineNumbers() {
    Row(Modifier.fillMaxWidth().height(36.dp).background(Color(0xFF15181E))) {
        Box(Modifier.width(128.dp).fillMaxHeight().border(1.dp, Grid), contentAlignment = Alignment.Center) { Text("TRACKS", color = Muted, fontSize = 10.sp) }
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            repeat(32) { i -> Box(Modifier.width(64.dp).fillMaxHeight().border(.5.dp, Grid), contentAlignment = Alignment.Center) { Text("${i + 1}", color = if (i % 4 == 0) Text else Muted, fontSize = 10.sp) } }
        }
    }
}

@Composable
fun TrackList(tracks: List<Track>, selected: Int, select: (Int) -> Unit, add: () -> Unit) {
    Column(Modifier.width(128.dp).fillMaxHeight().background(Panel)) {
        tracks.forEachIndexed { i, t ->
            Row(Modifier.fillMaxWidth().height(72.dp).background(if (selected == i) Color(0xFF20252C) else Panel).border(.5.dp, Grid).clickable { select(i) }.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column { Text(t.name, color = Text, fontSize = 13.sp, fontWeight = FontWeight.Bold); Text(t.type, color = Muted, fontSize = 10.sp) }
            }
        }
        Box(Modifier.fillMaxWidth().height(52.dp).clickable { add() }, contentAlignment = Alignment.Center) { Text("+ ADD TRACK", color = Lime, fontSize = 11.sp) }
    }
}

@Composable
fun Timeline(count: Int, selected: Int) {
    Row(Modifier.fillMaxSize().horizontalScroll(rememberScrollState()).background(Bg)) {
        Column {
            repeat(count) { row ->
                Box(Modifier.width(2048.dp).height(72.dp).background(if (row == selected) Color(0xFF10151A) else Bg)) {
                    Row { repeat(32) { c -> Box(Modifier.width(64.dp).fillMaxHeight().border(.5.dp, if (c % 4 == 0) Color(0xFF363B45) else Grid)) } }
                    when (row) { 0 -> Clip("DRUM LOOP", 0, 4); 1 -> Clip("BASS", 4, 5); 2 -> Clip("MELODY", 8, 4) }
                }
            }
        }
    }
}

@Composable
fun Clip(name: String, start: Int, length: Int) {
    Box(Modifier.offset(x = (start * 64).dp, y = 7.dp).width((length * 64).dp).height(58.dp).padding(4.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF394A21)).border(1.dp, Lime), contentAlignment = Alignment.CenterStart) {
        Text(name, color = Text, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
    }
}
